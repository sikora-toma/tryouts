//
//  UIButtonService.swift
//  tryouts
//
//  Created by Toma Sikora on 10/05/2019.
//  Copyright © 2019 Toma Sikora. All rights reserved.
//

import Foundation
import UIKit

class UIButtonService {
//postavi constrainte fizicki za button ovisno o tekstu koji je u njemu
    func setRoundedButton(button: UIButton, width: CGFloat, height: CGFloat, text: String, backgroundColor: UIColor) -> Void {
        button.backgroundColor = backgroundColor
        button.frame = CGRect(x: button.frame.minX, y: button.frame.minY, width: width, height: height)
        button.setTitle(text, for: UIControl.State.normal)
        button.titleLabel?.adjustsFontSizeToFitWidth = true
        button.titleLabel?.textAlignment = NSTextAlignment.center
        button.contentVerticalAlignment = UIControl.ContentVerticalAlignment.top
        if (button.bounds.size.height>button.bounds.size.width){
            button.layer.cornerRadius = 0.5 * button.bounds.size.width
        }else {
            button.layer.cornerRadius = 0.5 * button.bounds.size.height
        }
        button.clipsToBounds = true
    }
    
    func setButtonImage(button: UIButton, image: UIImage) {
        button.setImage(image, for: UIControl.State.normal)
        button.imageView!.contentMode = UIView.ContentMode.scaleAspectFit
        button.contentMode = .center
    }
}
