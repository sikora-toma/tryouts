//
//  UISegmentedControlService.swift
//  tryouts
//
//  Created by Toma Sikora on 10/05/2019.
//  Copyright © 2019 Toma Sikora. All rights reserved.
//

import Foundation
import UIKit

class UISegmentedControlService {
    func setSegmentedControl(control: UISegmentedControl, width: CGFloat, height: CGFloat, firstText: String, secondText: String, tintColor: UIColor, backgroundColor: UIColor) {
        control.backgroundColor = backgroundColor
        control.frame = CGRect(x: control.frame.minX, y: control.frame.minY, width: width, height: height)
        control.setTitle(firstText, forSegmentAt: 0)
        control.setTitle(secondText, forSegmentAt: 1)
        control.tintColor = tintColor
        if (control.bounds.size.height>control.bounds.size.width){
            control.layer.cornerRadius = 0.5 * control.bounds.size.width
        }else {
            control.layer.cornerRadius = 0.5 * control.bounds.size.height
        }
        control.clipsToBounds = true
        control.removeBorders()
    }
}
extension UISegmentedControl {
    func removeBorders() {
        setBackgroundImage(imageWithColor(color: backgroundColor!), for: .normal, barMetrics: .default)
        setBackgroundImage(imageWithColor(color: tintColor!), for: .selected, barMetrics: .default)
        setDividerImage(imageWithColor(color: UIColor.clear), forLeftSegmentState: .normal, rightSegmentState: .normal, barMetrics: .default)
    }
    
    // create a 1x1 image with this color
    private func imageWithColor(color: UIColor) -> UIImage {
        let rect = CGRect(x: 0.0, y: 0.0, width:  1.0, height: 1.0)
        UIGraphicsBeginImageContext(rect.size)
        let context = UIGraphicsGetCurrentContext()
        context!.setFillColor(color.cgColor);
        context!.fill(rect);
        let image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        return image!
    }
}
