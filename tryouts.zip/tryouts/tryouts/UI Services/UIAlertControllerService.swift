//
//  UIAlertControllerService.swift
//  tryouts
//
//  Created by Toma Sikora on 12/05/2019.
//  Copyright © 2019 Toma Sikora. All rights reserved.
//

import Foundation
import UIKit

class UIAlertControllerService {
    func setUIAlertController(alert: UIAlertController) {
        alert.view.backgroundColor = UIColor.white
        alert.view.layer.cornerRadius = 15
        alert.view.layer.masksToBounds = true
    }
}
