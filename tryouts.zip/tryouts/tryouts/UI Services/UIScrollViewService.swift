//
//  UIScrollViewService.swift
//  tryouts
//
//  Created by Toma Sikora on 13/05/2019.
//  Copyright © 2019 Toma Sikora. All rights reserved.
//

import Foundation
import UIKit

class UIScrollViewService {
    func setupImages(_ images: [UIImage], scrollView: UIScrollView) {
        
        for i in 0..<images.count {
            let imageView = UIImageView()
            imageView.image = images[i]
            let xPos = UIScreen.main.bounds.width * CGFloat(i)
            imageView.frame = CGRect(x: xPos, y: 0, width: scrollView.frame.width, height: scrollView.frame.height)
            imageView.contentMode = .scaleAspectFit
            
            scrollView.contentSize.width = scrollView.frame.width * CGFloat(i+1)
            scrollView.addSubview(imageView)
            //scrollView.delegate = self
        }
    }
    
    func setupParameters(scrollView: UIScrollView) {
        scrollView.backgroundColor = UIColor.black
        scrollView.isPagingEnabled = true
        scrollView.showsHorizontalScrollIndicator = true
    }
}
