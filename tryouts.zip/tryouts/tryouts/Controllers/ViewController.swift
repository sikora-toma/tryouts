//
//  ViewController.swift
//  tryouts
//
//  Created by Toma Sikora on 10/05/2019.
//  Copyright © 2019 Toma Sikora. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var button: UIButton!
    @IBOutlet weak var secondButton: UIButton!
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    @IBOutlet weak var scrollView: UIScrollView!
    
    let alertController = UIAlertController(title: "You have arrived successfully on your location",
                                            message: "A standard alert.", preferredStyle: .alert)
    let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (action) in print("Cancel")}
    let OKAction = UIAlertAction(title: "OK", style: .default) { (action) in print("OK")}
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//setup two buttons
        UIButtonService().setRoundedButton(button: button, width: 50, height: 50, text: "asdf", backgroundColor: UIColor.yellow)
        //UIButtonService().setButtonImage(button: button, image: UIImage(named: "plus")!)
        
        UIButtonService().setRoundedButton(button: secondButton, width: 50, height: 50, text: "@", backgroundColor: UIColor.yellow)
        
//setup segmentedControl
        UISegmentedControlService().setSegmentedControl(control: segmentedControl, width: 200, height: 50, firstText: "Prvi", secondText: "Drugi", tintColor: UIColor.red, backgroundColor: UIColor.yellow)
        
//setup alertController
        alertController.addAction(cancelAction)
        alertController.addAction(OKAction)
        UIAlertControllerService().setUIAlertController(alert: alertController)
 
//setup ScrollView
        let imageArray = [#imageLiteral(resourceName: "52551814-black-vintage-custom-motorcycle-motorbike-cafe-racer-with-black-full-face-helmet-in-front-of-brick-w"), #imageLiteral(resourceName: "Image-1"), #imageLiteral(resourceName: "Image")]
        UIScrollViewService().setupImages(imageArray, scrollView: scrollView)
        UIScrollViewService().setupParameters(scrollView: scrollView)
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        present(alertController, animated: true)
    }

    
//definiranje akcija ovisno i odabranon segmentu
    @IBAction func indexChanged(_ sender: Any) {
        switch segmentedControl.selectedSegmentIndex
        {
        case 0:
            print("First Segment Selected")
        case 1:
            print("Second Segment Selected")
        default:
            break
        }
    }
    
    
    @IBAction func showAttractionPreview(_ sender: Any) {
//        let attractionPreview = AttractionPreviewViewController()
//        self.present(attractionPreview, animated: true, completion: nil)
        let attractionInfo = AttractionInfoViewController()
//        self.present(attractionInfo, animated: true, completion: nil)
        navigationController?.pushViewController(attractionInfo, animated: true)
    }
}

