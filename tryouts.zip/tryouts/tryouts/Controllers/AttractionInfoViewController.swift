//
//  AttractionInfoViewController.swift
//  tryouts
//
//  Created by Toma Sikora on 17/05/2019.
//  Copyright © 2019 Toma Sikora. All rights reserved.
//

import UIKit

class AttractionInfoViewController: UIViewController {
    
    @IBOutlet weak var scroll: UIScrollView!
    @IBOutlet weak var home: UIButton!
    @IBOutlet weak var back: UIButton!
    @IBOutlet weak var attractionTitle: UILabel!
    @IBOutlet weak var playAudio: UIButton!
    @IBOutlet weak var attractionDescription: UILabel!
    @IBOutlet weak var viewAttraction: UIButton!
    @IBOutlet weak var location: UIButton!
    
    var attractionName: String? = nil
    var descriptionText: String? = nil
    var images: [UIImage]? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func viewDidAppear(_ animated: Bool) {
        let imageArray = [#imageLiteral(resourceName: "Image"), #imageLiteral(resourceName: "Image-1"), #imageLiteral(resourceName: "52551814-black-vintage-custom-motorcycle-motorbike-cafe-racer-with-black-full-face-helmet-in-front-of-brick-w")]
        attractionName = "Palača"
        descriptionText = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
        images = imageArray
        setAttractionPreview()
    }

    func setAttractionPreview() {
        attractionTitle.text = attractionName
        attractionTitle.adjustsFontSizeToFitWidth = true
        attractionDescription.text = descriptionText
        attractionDescription.adjustsFontSizeToFitWidth = true
        
        UIScrollViewService().setupImages(images!, scrollView: scroll)
        UIScrollViewService().setupParameters(scrollView: scroll)
        
        UIButtonService().setRoundedButton(button: viewAttraction, width: viewAttraction.frame.width, height: viewAttraction.frame.height, text: "View attraction", backgroundColor: UIColor.blue)
        viewAttraction.setTitleColor(UIColor.white, for: UIControl.State.normal)
        viewAttraction.contentVerticalAlignment = .center
        
        UIButtonService().setButtonImage(button: home, image: #imageLiteral(resourceName: "plus"))
        home.setTitle("", for: UIControl.State.normal)
        home.backgroundColor = UIColor.clear
        home.tintColor = UIColor.white
        view.bringSubviewToFront(home)
        
        playAudio.setTitle("Play audio", for: UIControl.State.normal)
        playAudio.backgroundColor = UIColor.clear
        
        location.setTitle("View my location", for: UIControl.State.normal)
        location.backgroundColor = UIColor.clear
        
        back.setTitle("Back", for: UIControl.State.normal)
        back.backgroundColor = UIColor.clear
        back.setTitleColor(UIColor.white, for: UIControl.State.normal)
        view.bringSubviewToFront(back)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
