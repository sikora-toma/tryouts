//
//  AttractionPreviewViewController.swift
//  tryouts
//
//  Created by Toma Sikora on 13/05/2019.
//  Copyright © 2019 Toma Sikora. All rights reserved.
//

import UIKit

class AttractionPreviewViewController: UIViewController {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var viewButton: UIButton!
    @IBOutlet weak var homeButton: UIButton!
    @IBOutlet weak var audioButton: UIButton!
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var imageScrollView: UIScrollView!
    
    var attractionName: String? = nil
    var descriptionText: String? = nil
    var images: [UIImage]? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        let imageArray = [#imageLiteral(resourceName: "Image"), #imageLiteral(resourceName: "Image-1"), #imageLiteral(resourceName: "52551814-black-vintage-custom-motorcycle-motorbike-cafe-racer-with-black-full-face-helmet-in-front-of-brick-w")]
        attractionName = "Palača"
        descriptionText = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
        images = imageArray
        setAttractionPreview()
    }
    
    func setAttractionPreview() {
        titleLabel.text = attractionName
        titleLabel.adjustsFontSizeToFitWidth = true
        descriptionLabel.text = descriptionText
        descriptionLabel.adjustsFontSizeToFitWidth = true
        
        UIScrollViewService().setupImages(images!, scrollView: imageScrollView)
        UIScrollViewService().setupParameters(scrollView: imageScrollView)
        
        UIButtonService().setRoundedButton(button: viewButton, width: viewButton.frame.width, height: viewButton.frame.height, text: "View attraction", backgroundColor: UIColor.blue)
        viewButton.setTitleColor(UIColor.white, for: UIControl.State.normal)
        viewButton.contentVerticalAlignment = .center
        
        UIButtonService().setButtonImage(button: homeButton, image: #imageLiteral(resourceName: "plus"))
        homeButton.setTitle("", for: UIControl.State.normal)
        homeButton.backgroundColor = UIColor.clear
        homeButton.tintColor = UIColor.white
        view.bringSubviewToFront(homeButton)
        
        audioButton.setTitle("Play audio", for: UIControl.State.normal)
        audioButton.backgroundColor = UIColor.clear
        
        backButton.setTitle("Back", for: UIControl.State.normal)
        backButton.backgroundColor = UIColor.clear
        backButton.setTitleColor(UIColor.white, for: UIControl.State.normal)
        view.bringSubviewToFront(backButton)
    }

    @IBAction func back(_ sender: Any) {
        view.removeFromSuperview()
    }
}
